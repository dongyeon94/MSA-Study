package com.example.root;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class RootApplicationTests {

	@Test
	void contextLoads() {
	}

}
